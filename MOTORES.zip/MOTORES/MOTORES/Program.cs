﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MOTORES
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opc = 0;
            double[] motores;
            motores = new double[15];
            int pos;
            int z=1;

            do
            {
                    
                Console.WriteLine("\n0. SAIR");
                Console.WriteLine("1. LANÇAR VALOR");
                Console.WriteLine("2. MOSTRAR VALORES");

                Console.WriteLine();

                Console.WriteLine("Selecione sua opção");
                opc = int.Parse(Console.ReadLine());

                Console.Clear();

                if (opc == 1)
                {
                    Console.Clear();

                    Console.WriteLine("Qual motor?");
                    pos =int.Parse(Console.ReadLine());

                     Console.Clear();

                    Console.WriteLine("Digite o valor gasto");
                    motores[--pos] = double.Parse(Console.ReadLine());

                    Console.WriteLine(); 


                }

                if (opc == 2)
                {
                    for (int x = 0;x < 15; x++)
                    {
                        Console.Write("\n Motor {0} valor {1}: ", z, motores[x] );
                        z++;
                    }
                    z = 0;


                }


            } while (opc != 0);

        }
    }
}
